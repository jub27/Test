#pragma once
#include<d3d9.h>
#include<d3dx9.h>

struct Planet
{
	D3DXMATRIX m_TM;
	D3DXMATRIX m_Rotation;
	D3DXMATRIX m_Rev;
	D3DXMATRIX m_Scale;
};