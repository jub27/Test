#include "Vertex.h"



Vertex::Vertex()
{
}


Vertex::~Vertex()
{
}

HRESULT Vertex::InitVB(LPDIRECT3DDEVICE9 & pDevice, float x, float y, float z, float Size)
{
	CUSTOMVERTEX vertices[] =
	{
		{-Size + x, Size + y, Size + z, D3DCOLOR_XRGB(255,255,0)}, //v0
		{ Size + x, Size + y, Size + z, D3DCOLOR_XRGB(0,255,0)}, //v1
		{ Size + x, Size + y,-Size + z, D3DCOLOR_XRGB(0,255,255)}, //v2
		{-Size + x, Size + y,-Size + z, D3DCOLOR_XRGB(255,0,255)}, //v3

		{-Size + x,-Size + y, Size + z, D3DCOLOR_XRGB(255,0,0)}, //v4
		{ Size + x,-Size + y, Size + z, D3DCOLOR_XRGB(200,0,200)}, //v5
		{ Size + x,-Size + y,-Size + z, D3DCOLOR_XRGB(0,120,120)}, //v6
		{-Size + x,-Size + y,-Size + z, D3DCOLOR_XRGB(120,120,120)}, //v7
	};

	if (FAILED(pDevice->CreateVertexBuffer(8 * sizeof(CUSTOMVERTEX), 0, D3DFVF_CUSTOMVERTEX,
		D3DPOOL_DEFAULT, &g_pVB, NULL)))
	{
		return E_FAIL;
	}

	//������ ���۸� ������ ä���.
	//���� ������ Lock() �Լ��� ȣ���Ͽ� �����͸� ���´�.
	void* pVertices;

	if (FAILED(g_pVB->Lock(0, sizeof(vertices), (void**)&pVertices, 0)))
	{
		return E_FAIL;
	}

	memcpy(pVertices, vertices, sizeof(vertices));

	g_pVB->Unlock();

	return S_OK;
}