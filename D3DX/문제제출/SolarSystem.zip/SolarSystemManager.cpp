#include "SolarSystemManager.h"

SolarSystemManager* SolarSystemManager::m_pThis = NULL;

SolarSystemManager::SolarSystemManager()
{
}


SolarSystemManager::~SolarSystemManager()
{
}

HRESULT SolarSystemManager::Init(LPDIRECT3DDEVICE9 &pDevice)
{
	if (SUCCEEDED(m_Vertex.InitVB(pDevice, 0, 0, 0, 1)))
	{
		if (SUCCEEDED(m_Index.InitIB(pDevice)))
		{
			return S_OK;
		}
	}
	return E_FAIL;
}

void SolarSystemManager::Cleanup()
{
	if (m_Vertex.GetpVB() != NULL)
		m_Vertex.GetpVB()->Release();

	if (m_Index.GetpIB() != NULL)
		m_Index.GetpIB()->Release();
}

void SolarSystemManager::SetupMatrix()
{
	D3DXMatrixIdentity(&m_Solar.m_TM);
	D3DXMatrixRotationY(&m_Solar.m_Rotation, GetTickCount() / 5000.0f);
	D3DXMatrixRotationZ(&m_Parent.m_Rotation, GetTickCount() / 1000.0f);

	D3DXVECTOR3 nomalPVec(-1, 1, 0);

	D3DXMatrixRotationAxis(&m_Parent.m_Rev, &nomalPVec, GetTickCount() / 1000.0f);
	D3DXMatrixTranslation(&m_Parent.m_TM, 3, 3, 3);

	D3DXMatrixScaling(&m_Child.m_Scale, 0.5f, 0.5f, 0.5f);
	D3DXMatrixRotationZ(&m_Child.m_Rotation, GetTickCount() / 7000.0f);

	D3DXVECTOR3 nomalCVec(-1, 1, 0);

	D3DXMatrixRotationAxis(&m_Child.m_Rev, &nomalCVec, GetTickCount() / 500.0f);
	D3DXMatrixTranslation(&m_Child.m_TM, 1.5f, 1.5f, 1.5f);
}
