#pragma once
#include"Singleton.h"
#include"Index.h"
#include"Vertex.h"
#include"Planet.h"

class SolarSystemManager : public Singleton<SolarSystemManager>
{
private:
	D3DXMATRIXA16 m_matWorld;
	Vertex m_Vertex;
	Index m_Index;
	Planet m_Solar;
	Planet m_Parent;
	Planet m_Child;
public:
	SolarSystemManager();
	~SolarSystemManager();

	HRESULT Init(LPDIRECT3DDEVICE9 &pDevice);
	void Cleanup();
	void SetupMatrix();
	inline Vertex GetVertex()
	{
		return m_Vertex;
	}
	inline Index GetIndex()
	{
		return m_Index;
	}
	inline Planet GetSolar()
	{
		return m_Solar;
	}
	inline Planet GetParent()
	{
		return m_Parent;
	}
	inline Planet GetChild()
	{
		return m_Child;
	}
};